// This information is used to generate the sitemap
export const sitemapConfig = {
  site: "", // https://example.com
  videoUrl:"",
  videoThumbnailUrl:"",
  videoTitle:"",
  videoDesc:"",
};
